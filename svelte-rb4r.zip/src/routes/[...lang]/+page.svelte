<script>
	import '$lib/main.css';
	import allContent from '$lib/content.json';
	import { page } from '$app/stores';
	import Header from '$lib/header.svelte';
	import Map from '$lib/map.svelte';
	import Tile from '$lib/components/tile.svelte';
	$: lang = $page.params.lang || 'en';
	$: content = lang in allContent ? allContent[lang] : allContent.en;
    let activeValue = 99
    $: console.log(activeValue)
	$: tileData = content.tiles
</script>

<Header {content} />

<Map bind:activeValue />
      <div class="content">
        <div class="content-text">
          <h3>{content.hero.header}</h3>
          <p>{content.hero.subtitle}</p>
        </div>
        <div class="tiles">
			{#each tileData as tile}
            <Tile tile={tile} key={tile.country} {activeValue} />;
{/each}
		</div>
      </div>
<style>
	.content {
		position: fixed;
		pointer-events: none;
		top: 75px;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: 999;
	}
</style>	