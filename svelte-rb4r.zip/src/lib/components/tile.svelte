<script>
    export let tile, activeValue
    </script>

<div class={activeValue == tile.number ? 'tile' : 'nope'}>
    <div class="tile-circle">
      <div class="circle" style={`background-color: #${tile.color}`}>
        {tile.number}
      </div>
    </div>
    <div class="tile-rectangle">
      <div class="tile-top-text">{tile.topText}</div>
      <div class="tile-bottom-text">{tile.bottomText}</div>
    </div>
    <div class="tile-image">
      <img
        width="160"
        height="160"
        src={`https://collections.newberry.org/IIIF3/Image/${tile.image}/square/,160/0/default.jpg`}
        alt=""
      />
    </div>
  </div>

  <style>
    .nope {
        display: none;
    }
    .tile {
  display: flex;
  justify-content: flex-start;
  height: 150px;
  flex-basis: 700px;
}

.tile-circle {
  flex-basis: 150px;
  border-radius: 50% 0 0 50%;
  border-top: 1px solid black;
  border-bottom: 1px solid black;
  border-left: 1px solid black;
  background: rgb(var(--granite));
}
.tile-rectangle {
  flex: 1;
  box-sizing: border-box;
  height: 150px;
  background: rgb(var(--granite));
  border-top: 1px solid black;
  border-right: 1px solid black;
  border-bottom: 1px solid black;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: flex-start;
  padding: 4px;
}
.circle {
  color: rgb(var(--midnight));
  border-radius: 50%;
  /* margin: 1px; */
  min-height: 148px;
  min-width: 148px;
  font-family: styrene;
  font-size: 50px;

  display: flex;
  justify-content: center;
  align-items: center;
}
.tile-image {
  box-sizing: border-box;
  width: 150px;
  height: 150px;
  overflow: hidden;
  border: 1px solid black;
  /* border-width: 1px 1px 1px 0; */
  /* border-color: rgb(var(--midnight)); */
}
.tile-image img {
  width: 160px;
  height: 160px;
  object-fit: cover;
}
.tile-top-text {
  font-size: 25px;
  line-height: 24px;
  font-weight: 900;
}
.tile-bottom-text {
  font-size: 20px;
  line-height: 18px;
}

    </style>